<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Video</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

	<?php 
		session_start();
		if (isset($_SESSION['log'])) {
			
		}else{
			echo "<script> window.location.href='login.php'</script>";
		}
		
		
	 ?>
</head>
<body>
	<div class="container">
		<div class="text-center my-auto">
			<img  src="https://seeklogo.com/images/M/mujib-sotoborso-logo-FE869827AE-seeklogo.com.jpg">
		</div>
		<div class="m-3">
			<form action="" method="post" enctype="multipart/form-data">
			<input class="form-control" type="text" name="link">
			<input class="btn btn-success w-100 float-right" type="submit" name="submit">
	</form>
		</div>
		<hr>
		<div class="row">
			<?php 	
			
				for ($si=0; $si <12 ; $si++) { 
					
				

			 ?>
			<div class="col-md-4">
				<iframe class="w-100" src="https://www.youtube.com/embed/<?php if (isset($_POST['submit'])) {echo $link=$_POST['link'];}?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>
		<?php 	} ?>
		</div>
		<p class="text-center">
			Copyright By <?= $_SERVER['HTTP_HOST'];?> <?= date("Y");?>
		</p>
		<p class="text-center">Deasigner MD SAZZAD helped by Shahariya</p>
	</div>

</body>
</html>