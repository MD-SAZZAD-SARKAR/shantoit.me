<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Video</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>
<body>
	
	<div class="container">
		<div class="text-center my-auto">

			<img  src="https://seeklogo.com/images/M/mujib-sotoborso-logo-FE869827AE-seeklogo.com.jpg">
		</div>
		<div class="m-3">
			<?php 
		session_start();
		if(isset($_POST['pass'])){
			$password=$_POST['pass'];
			if($password==="01518408745"){
				$_SESSION['log']="login sccess";
				if (isset($_SESSION['log'])) {
			echo "<script> window.location.href='video.php'</script>";
		}
			}else{
				echo "Your password wrong";
			}
		}
		
			
		
		
		
	 ?>
			<form action="" method="post" enctype="multipart/form-data">
			<input class="form-control" type="text" placeholder="Enter your password" name="pass">
			<input class="btn btn-success w-100 float-right" type="submit" name="submit">
	</form>
		</div>
		<hr>
		
		<p class="text-center">
			Copyright By <?= $_SERVER['HTTP_HOST'];?> <?= date("Y");?>
		</p>
		<p class="text-center">Deasigner MD SAZZAD helped by Shahariya</p>
	</div>

</body>
</html>